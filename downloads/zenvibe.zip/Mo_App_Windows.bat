@echo off
title ZenVibe - Ambient Sound Mixer
echo ========================================================
echo   ZenVibe - Relaxing Ambient Sounds
echo ========================================================
echo.
echo Dang khoi chay may chu tai http://localhost:8080 ...
echo Nhap Ctrl+C de dung.
start http://localhost:8080
python -m http.server 8080
if %errorlevel% neq 0 (
    echo.
    echo May ban chua cai Python. Dang mo truc tiep index.html...
    start index.html
)
pause
